/**
 * UserDoesNotExistException is an exception where a user does not exist 
 */
package exceptions;

public class UserNotFoundException extends Exception {
	private static final long serialVersionUID = 1L;
	
}
